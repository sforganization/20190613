
#if 0
#ifndef __PWM_H
#define __PWM_H
#include "sys.h"

void San_SoftPWMInit(u16 arr,u16 psc);
#endif
#endif
