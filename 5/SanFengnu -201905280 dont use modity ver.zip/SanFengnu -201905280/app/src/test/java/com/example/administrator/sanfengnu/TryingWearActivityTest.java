package com.example.administrator.sanfengnu;

import org.junit.Test;

public class TryingWearActivityTest {

    @Test
    public void hideBottomKey() {
    }

    @Test
    public void makeStringtoFramePackage() {
    }

    @Test
    public void onDestroy() {
    }

    @Test
    public void onCreate() {
    }
}